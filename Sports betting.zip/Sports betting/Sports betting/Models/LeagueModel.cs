﻿namespace Sports_betting.Models
{
    public class LeagueModel
    {
        public int LeagueID { get; set; } 
        public string LeagueName { get; set; }

    }
}
