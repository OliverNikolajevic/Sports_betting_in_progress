﻿namespace Sports_betting.Models
{
    public class MatchModel
    {
        public int MatchID { get; set; } 
        public TimeSpan StartTime { get; set; }
        public int LeagueID { get; set; }
        public int HomeTeamID { get; set; }
        public int AwayTeamID { get; set; }
        public string Result { get; set; }

        public virtual LeagueModel League { get; set; }
        public virtual TeamModel HomeTeam { get; set; }
        public virtual TeamModel AwayTeam { get; set; }
    }
}
