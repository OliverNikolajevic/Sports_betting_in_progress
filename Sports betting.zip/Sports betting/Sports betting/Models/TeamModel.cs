﻿namespace Sports_betting.Models
{
    public class TeamModel
    {
        public int TeamID { get; set; }
        public string TeamName { get; set; }
    }
   
}
