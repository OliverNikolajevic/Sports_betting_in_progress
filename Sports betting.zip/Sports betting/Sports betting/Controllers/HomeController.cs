﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using OfficeOpenXml;
using Sports_betting.Models;
using System.Diagnostics;
using System.Globalization;
using System.Text;
using System.Xml.Serialization;

namespace Sports_betting.Controllers
{
    public class HomeController : Controller
    {
        private readonly BettingDbContext _dbContext;
        private readonly ILogger<HomeController> _logger;
        private readonly IWebHostEnvironment _env;

        public HomeController(ILogger<HomeController> logger, BettingDbContext dbContext, IWebHostEnvironment env)
        {
            _logger = logger;
            _dbContext = dbContext;
            _env = env;
        }
        public IActionResult Index()
        {
            List<MatchModel> matches = _dbContext.Matches
                .Include(m => m.League)
                .Include(m => m.HomeTeam)
                .Include(m => m.AwayTeam)
                .ToList();

            return View(matches);
        }



        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public IActionResult CreateMatch()
        {
            ViewBag.Leagues = _dbContext.Leagues.ToList();
            ViewBag.Teams = _dbContext.Teams.ToList();
            return View(new MatchModel());
        }


        [HttpPost]
        public IActionResult CreateMatch(MatchModel newMatch)
        {

            foreach (var modelState in ViewData.ModelState.Values)
            {
                foreach (var error in modelState.Errors)
                {
                    _logger.LogError(error.ErrorMessage);
                }
            }


            ModelState.Clear();


            newMatch.League = _dbContext.Leagues.Find(newMatch.LeagueID);
            newMatch.HomeTeam = _dbContext.Teams.Find(newMatch.HomeTeamID);
            newMatch.AwayTeam = _dbContext.Teams.Find(newMatch.AwayTeamID);


            TryValidateModel(newMatch);


            foreach (var modelState in ViewData.ModelState.Values)
            {
                foreach (var error in modelState.Errors)
                {
                    _logger.LogError(error.ErrorMessage);
                }
            }

            if (ModelState.IsValid)
            {
                _dbContext.Matches.Add(newMatch);

                try
                {
                    _dbContext.SaveChanges();
                    return RedirectToAction(nameof(Index), "Home");
                }
                catch (DbUpdateException ex)
                {
                    _logger.LogError(ex, "Error while saving changes to the database.");
                    throw;
                }
            }

            ViewBag.Leagues = _dbContext.Leagues.ToList();
            ViewBag.Teams = _dbContext.Teams.ToList();
            return View(newMatch);
        }


        public IActionResult CreateLeague()
        {
            return View();
        }


        [HttpPost]
        public IActionResult CreateLeague(LeagueModel newLeague)
        {
            if (ModelState.IsValid)
            {
                _dbContext.Leagues.Add(newLeague);
                _dbContext.SaveChanges();

                return RedirectToAction("Index");
            }

            return View(newLeague);
        }



        public IActionResult CreateTeam()
        {
            return View();
        }

        [HttpPost]
        public IActionResult CreateTeam(TeamModel newTeam)
        {
            if (ModelState.IsValid)
            {
                _dbContext.Teams.Add(newTeam);
                _dbContext.SaveChanges();

                return RedirectToAction("Index");
            }

            return View(newTeam);
        }


        public IActionResult ExportMatchesToExcel()
        {
            var matches = _dbContext.Matches
                .Include(m => m.League)
                .Include(m => m.HomeTeam)
                .Include(m => m.AwayTeam)
                .ToList();

            var excelBytes = ExportToExcel(matches);

            string contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            string fileName = "matches.xlsx";

            return File(excelBytes, contentType, fileName);
        }
        private string GetExportFolderPath()
        {
            string appRoot = _env.ContentRootPath;
            string exportFolder = Path.Combine(appRoot, "ExportExcel");

            if (!Directory.Exists(exportFolder))
            {
                Directory.CreateDirectory(exportFolder);
            }

            return exportFolder;
        }

        private void SaveExcelToFile(ExcelPackage package, string filePath)
        {
            using (FileStream fileStream = new FileStream(filePath, FileMode.Create))
            {
                package.SaveAs(fileStream);
            }
        }

        private byte[] ExportToExcel(List<MatchModel> matches)
        {
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
            using (var package = new ExcelPackage())
            {
                var worksheet = package.Workbook.Worksheets.Add("Matches");


                worksheet.Cells[1, 1].Value = "Start Time";
                worksheet.Cells[1, 2].Value = "Code";
                worksheet.Cells[1, 3].Value = "League";
                worksheet.Cells[1, 4].Value = "Home Team";
                worksheet.Cells[1, 5].Value = "Away Team";
                worksheet.Cells[1, 6].Value = "Result";


                for (int row = 0; row < matches.Count; row++)
                {
                    worksheet.Cells[row + 2, 1].Value = matches[row].StartTime.ToString(@"hh\:mm");

                    worksheet.Cells[row + 2, 2].Value = matches[row].LeagueID;
                    worksheet.Cells[row + 2, 3].Value = matches[row].League.LeagueName;
                    worksheet.Cells[row + 2, 4].Value = matches[row].HomeTeam.TeamName;
                    worksheet.Cells[row + 2, 5].Value = matches[row].AwayTeam.TeamName;
                    worksheet.Cells[row + 2, 6].Style.Numberformat.Format = "0:0";
                    worksheet.Cells[row + 2, 6].Value = matches[row].Result;
                }
                string exportFolder = GetExportFolderPath();
                string filePath = Path.Combine(exportFolder, "matches.xlsx");

                SaveExcelToFile(package, filePath);

                return package.GetAsByteArray();
            }
        }



        public IActionResult ExportMatchesToXml()
        {
            var matches = _dbContext.Matches
                .Include(m => m.League)
                .Include(m => m.HomeTeam)
                .Include(m => m.AwayTeam)
                .ToList();

            var xmlBytes = ExportToXml(matches);

            string contentType = "application/xml";
            string fileName = "matches.xml";

            string exportFolder = Path.Combine(_env.ContentRootPath, "ExportXml");  
            string xmlFilePath = Path.Combine(exportFolder, fileName);  

            using (var stream = new FileStream(xmlFilePath, FileMode.Create))
            {
                stream.Write(xmlBytes, 0, xmlBytes.Length);
            }

            return File(xmlBytes, contentType, fileName);
        }

        private byte[] ExportToXml(List<MatchModel> matches)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(List<MatchModel>));

            using (var memoryStream = new MemoryStream())
            {
                using (var writer = new StreamWriter(memoryStream, Encoding.UTF8))
                {
                    serializer.Serialize(writer, matches);
                }
                return memoryStream.ToArray();
            }
        }
        
     
        [HttpPost]
        public IActionResult DeleteMatch(int id)
        {
            var match = _dbContext.Matches.FirstOrDefault(m => m.MatchID == id);

            if (match == null)
            {
                return NotFound();
            }

            _dbContext.Matches.Remove(match);
            _dbContext.SaveChanges();

            return RedirectToAction("Index");
        }
        [HttpPost]
        public IActionResult ConfirmDeleteMatch(int id)
        {
           
            return RedirectToAction("Index");
        }

        public IActionResult EditMatch(int id)
        {
            var match = _dbContext.Matches
                .Include(m => m.League)
                .Include(m => m.HomeTeam)
                .Include(m => m.AwayTeam)
                .FirstOrDefault(m => m.MatchID == id);

            if (match == null)
            {
                return NotFound();
            }

            ViewBag.Leagues = _dbContext.Leagues.ToList();
            ViewBag.Teams = _dbContext.Teams.ToList();

            return View(match);
        
        }

        [HttpPost]
        public IActionResult EditMatch(MatchModel editedMatch)
        {
            if (ModelState.IsValid)
            {
                var matchToUpdate = _dbContext.Matches.FirstOrDefault(m => m.MatchID == editedMatch.MatchID);

                if (matchToUpdate == null)
                {
                    return NotFound();
                }

                matchToUpdate.StartTime = editedMatch.StartTime;
                matchToUpdate.LeagueID = editedMatch.LeagueID;
                matchToUpdate.HomeTeamID = editedMatch.HomeTeamID;
                matchToUpdate.AwayTeamID = editedMatch.AwayTeamID;
                matchToUpdate.Result = editedMatch.Result;

                _dbContext.SaveChanges();

                return RedirectToAction(nameof(Index), "Home");
            }

            ViewBag.Leagues = _dbContext.Leagues.ToList();
            ViewBag.Teams = _dbContext.Teams.ToList();
            return View(editedMatch);
        }

    }
}




