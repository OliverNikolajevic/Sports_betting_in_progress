﻿using Microsoft.EntityFrameworkCore;
using Sports_betting.Models;
using System.Collections.Generic;

public class BettingDbContext : DbContext
{
    private readonly ILoggerFactory _loggerFactory;
    public BettingDbContext(DbContextOptions<BettingDbContext> options, ILoggerFactory loggerFactory) : base(options)
    {
        _loggerFactory = loggerFactory;
    }
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<LeagueModel>().HasKey(l => l.LeagueID); 
        modelBuilder.Entity<TeamModel>().HasKey(t => t.TeamID); 
        modelBuilder.Entity<MatchModel>().HasKey(m => m.MatchID); 


    }

    public DbSet<LeagueModel> Leagues { get; set; }
    public DbSet<TeamModel> Teams { get; set; }
    public DbSet<MatchModel> Matches { get; set; }
}